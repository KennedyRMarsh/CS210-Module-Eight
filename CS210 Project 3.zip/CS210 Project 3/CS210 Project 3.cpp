// CS210 Project 3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


//read inventory of .txt file (loop)
//return set of GrocereyItem
    //Read names in file
    //create GroceryItem pointer
    //use set .find
    //IF already in set
        //copy existing name
        //copy existing quantity
        //erase item from set
        //reassign GroceryItem 

 //declare GroceryItem set


//CHECK if item already in set




//MENUE OPTION 1
// prompt user to input item / qword
// return # of times word is input (freqeucny)


//MENUE OPTION 2
//print list with number that represents frequency of all item purchases (Item #=

//MENUE OPTION 3
//print frequency as histogram
//print name followed by astrisks = frequency

//MENUE OPTION 4
//exit

